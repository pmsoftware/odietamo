package dbfit;

import dbfit.environment.OracleEnvironment;

public class OracleTest extends DatabaseTest {
	public OracleTest() {
		super(new OracleEnvironment());
	}
	public void dbfitDotOracleTest() {
		// required by fitnesse release 20080812
	}

}
